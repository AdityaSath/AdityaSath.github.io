function initTypewriterEffect(firstPart, secondPart) {
	const welcomeText = document.getElementById('welcomeText');
	if (!welcomeText) return;
	
	welcomeText.innerHTML = '';
	
	let i = 0;
	const typeSpeed = 50;
	const eraseSpeed = 30;
	let isErasing = false;
	
	function typeChar() {
	  if (!isErasing && i < firstPart.length) {
		// Typing first part
		const typedSpan = document.createElement('span');
		typedSpan.textContent = firstPart.substring(0, i + 1);
		
		const cursorSpan = document.createElement('span');
		cursorSpan.textContent = '|';
		cursorSpan.style.color = '#00ffff';
		cursorSpan.style.animation = 'blink 1s infinite';
		cursorSpan.style.fontWeight = 'normal';
		cursorSpan.style.opacity = '0.8';
		
		welcomeText.innerHTML = '';
		welcomeText.appendChild(typedSpan);
		welcomeText.appendChild(cursorSpan);
		
		i++;
		setTimeout(typeChar, typeSpeed);
	  } else if (!isErasing && i >= firstPart.length) {
		// Finished typing first part, pause then start erasing
		setTimeout(() => {
		  isErasing = true;
		  i = firstPart.length - 1;
		  typeChar();
		}, 1500);
	  } else if (isErasing && i >= 0) {
		// Erasing first part
		const typedSpan = document.createElement('span');
		typedSpan.textContent = firstPart.substring(0, i);
		
		const cursorSpan = document.createElement('span');
		cursorSpan.textContent = '|';
		cursorSpan.style.color = '#00ffff';
		cursorSpan.style.animation = 'blink 1s infinite';
		cursorSpan.style.fontWeight = 'normal';
		cursorSpan.style.opacity = '0.8';
		
		welcomeText.innerHTML = '';
		welcomeText.appendChild(typedSpan);
		welcomeText.appendChild(cursorSpan);
		
		i--;
		setTimeout(typeChar, eraseSpeed);
	  } else if (isErasing && i < 0) {
		// Finished erasing, start typing second part
		i = 0;
		setTimeout(() => {
		  typeSecondPart();
		}, 500);
	  }
	}
	
	function typeSecondPart() {
		if (i < secondPart.length) {
			const typedSpan = document.createElement('span');
			typedSpan.textContent = secondPart.substring(0, i + 1);
			
			const cursorSpan = document.createElement('span');
			cursorSpan.textContent = '|';
			cursorSpan.style.color = '#00ffff';
			cursorSpan.style.animation = 'blink 1s infinite';
			cursorSpan.style.fontWeight = 'normal';
			cursorSpan.style.opacity = '0.8';
			
			welcomeText.innerHTML = '';
			welcomeText.appendChild(typedSpan);
			welcomeText.appendChild(cursorSpan);
			
			i++;
			setTimeout(typeSecondPart, typeSpeed);
		} else {
			// Typing complete, remove cursor after a delay
			isTypingThirdPart = true;
			setTimeout(() => {
				welcomeText.innerHTML = secondPart;
				
				// Add author name with fade-in
				const authorSpan = document.createElement('div');
				authorSpan.textContent = '— Norman Vincent Peale';  // CHANGE THIS per page
				authorSpan.style.fontSize = 'clamp(14px, 3vw, 24px)';
				authorSpan.style.color = 'rgba(255, 255, 255, 0.7)';
				authorSpan.style.fontStyle = 'italic';
				authorSpan.style.opacity = '0';
				authorSpan.style.transition = 'opacity 2s ease';
				authorSpan.style.position = 'absolute';
				authorSpan.style.top = '100%';
				authorSpan.style.left = '50%';
				authorSpan.style.transform = 'translateX(-50%)';
				authorSpan.style.marginTop	 = '20px';
				authorSpan.style.whiteSpace = 'nowrap';
				
				welcomeText.appendChild(authorSpan);
				
				// Trigger fade-in
				setTimeout(() => {
					authorSpan.style.opacity = '1';
				}, 100);
			}, 2000);
		}
	}
	
	// Start typing after a short delay
	setTimeout(typeChar, 500);
  }
  
  const quoteFirstHalf = "Don't tell me the sky's the limit...";
  const quoteSecondHalf = "When there are footprints on the Moon";
  
  // Initialize typewriter effect when DOM is loaded
  document.addEventListener('DOMContentLoaded', () => {
	initTypewriterEffect(quoteFirstHalf, quoteSecondHalf);
  });

  // about.js
document.addEventListener("DOMContentLoaded", () => {
	const cards = document.querySelectorAll(".about-card");
  
	const observer = new IntersectionObserver(
	  (entries) => {
		entries.forEach((entry) => {
		  if (entry.isIntersecting) {
			entry.target.classList.add("visible");
			observer.unobserve(entry.target); // Animate once
		  }
		});
	  },
	  { threshold: 0.2 }
	);
  
	cards.forEach((card) => observer.observe(card));
  });
  
// Typing + erasing effect
const words = ["Aditya", "a Software Engineer", "an Adventurer", "a Space Enthusiast"];
let wordIndex = 0;
let charIndex = 0;
let isDeleting = false;
const span = document.getElementById("changing-word");
const typingSpeed = 80;   // typing speed in ms
const erasingSpeed = 50;   // erasing speed in ms
const delayBetween = 3000; // pause before erasing next word

function typeEffect() {
  const currentWord = words[wordIndex];

  if (!isDeleting && charIndex < currentWord.length) {
    span.textContent = currentWord.substring(0, charIndex + 1);
    charIndex++;
    setTimeout(typeEffect, typingSpeed);
  } else if (isDeleting && charIndex > 0) {
    span.textContent = currentWord.substring(0, charIndex - 1);
    charIndex--;
    setTimeout(typeEffect, erasingSpeed);
  } else {
    if (!isDeleting) {
      // Finished typing the word — pause before deleting
      isDeleting = true;
      setTimeout(typeEffect, delayBetween);
    } else {
      // Finished deleting — move to the next word
      isDeleting = false;
      wordIndex = (wordIndex + 1) % words.length;
      setTimeout(typeEffect, typingSpeed);
    }
  }
}

document.addEventListener("DOMContentLoaded", () => {
  setTimeout(typeEffect, 1000); // 1s delay before starting
});
